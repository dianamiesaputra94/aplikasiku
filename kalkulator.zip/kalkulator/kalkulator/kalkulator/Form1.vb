﻿Public Class Form1
    Dim clearDisplay As Boolean
    Dim Operand1 As Double, Operand2 As Double
    Dim [Operator] As String
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click, Button2.Click,
        Button3.Click, Button4.Click, Button5.Click, Button6.Click, Button7.Click, Button8.Click, Button9.Click, Button10.Click

        If clearDisplay Then
            TextBox1.Text = ""
            clearDisplay = False
        End If
        TextBox1.Text = Val(TextBox1.Text + sender.text)
    End Sub

    Private Sub Form1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If System.Char.IsDigit(e.KeyChar) Or e.KeyChar = "." Then
            If clearDisplay Then
                TextBox1.Text = ""
                clearDisplay = False
            End If
            TextBox1.Text = TextBox1.Text + e.KeyChar
        End If

    End Sub

    Private Sub c_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles c.Click
        TextBox1.Text = ""
    End Sub

    Private Sub bgi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bgi.Click
        Operand1 = Val(TextBox1.Text)
        [Operator] = "/"
        clearDisplay = True
    End Sub

    Private Sub jml_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles jml.Click
        Operand1 = Val(TextBox1.Text)
        [Operator] = "+"
        clearDisplay = True
    End Sub

    Private Sub krng_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles krng.Click
        Operand1 = Val(TextBox1.Text)
        [Operator] = "-"
        clearDisplay = True
    End Sub

    Private Sub kali_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles kali.Click
        Operand1 = Val(TextBox1.Text)
        [Operator] = "*"
        clearDisplay = True
    End Sub
    Private Sub persen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles persen.Click
        Operand1 = Val(TextBox1.Text)
        [Operator] = "%"
        clearDisplay = True
    End Sub

    Private Sub hsl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles hsl.Click

        Dim result2 As Double
        Operand2 = Val(TextBox1.Text)
        Try
            Select Case [Operator]
                Case "+"
                    result2 = Operand1 + Operand2
                Case "-"
                    result2 = Operand1 - Operand2
                Case "*"
                    result2 = Operand1 * Operand2
                Case "%"
                    result2 = Operand1 / 100
                Case "/"
                    result2 = Operand1 / Operand2
                    If Operand2 <> "0" Then
                        TextBox1.Text = result2
                    End If
            End Select
        Catch exc As Exception
            MsgBox(exc.Message)
            result2 = "ERROR"
        Finally
            TextBox1.Text = result2
            clearDisplay = True
        End Try
    End Sub

    Private Sub titik_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles titik.Click

        If TextBox1.Text.IndexOf(".") > 0 Then
            Exit Sub

        Else
            TextBox1.Text = TextBox1.Text & "."
        End If
    End Sub

   
End Class
